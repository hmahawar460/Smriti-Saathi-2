/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import { useState } from "react";
import {
  initialPatientProfile,
  initialTasks,
  initialFreePlayGames,
  initialReminders,
  sevenDayPerformance,
  activeAlert,
  initialNotes,
  initialPhysicalActivities
} from "./data/initialData";
import { Header } from "./components/common/Header";
import { VoiceModal } from "./components/common/VoiceModal";
import { CallCaregiverModal } from "./components/common/CallCaregiverModal";
import { PatientHome } from "./components/patient/PatientHome";
import { PatientTasks } from "./components/patient/PatientTasks";
import { AllGamesEngine } from "./components/games/AllGamesEngine";
import { PhysicalMemoryEngine } from "./components/games/PhysicalMemoryEngine";
import { PatientProgress } from "./components/patient/PatientProgress";
import { PatientAIAnalysis } from "./components/patient/PatientAIAnalysis";
import { PatientFreePlay } from "./components/patient/PatientFreePlay";
import { PhysicalActivityEngine } from "./components/patient/PhysicalActivityEngine";
import { OfflineGamesCenter } from "./components/patient/OfflineGamesCenter";
import { FamilyDashboard } from "./components/family/FamilyDashboard";
import { DoctorDashboard } from "./components/doctor/DoctorDashboard";
import { DesktopLayout } from "./components/desktop/DesktopLayout";
import { MultiFrameShowcase } from "./components/showcase/MultiFrameShowcase";
export default function App() {
  const [currentRole, setCurrentRole] = useState("showcase");
  const [profile, setProfile] = useState(initialPatientProfile);
  const [tasks, setTasks] = useState(initialTasks);
  const [physicalActivities, setPhysicalActivities] = useState(initialPhysicalActivities);
  const [freePlayGames, setFreePlayGames] = useState(initialFreePlayGames);
  const [reminders, setReminders] = useState(initialReminders);
  const [performance, setPerformance] = useState(sevenDayPerformance);
  const [alertData, setAlertData] = useState(activeAlert);
  const [notes, setNotes] = useState(initialNotes);
  const [activeTask, setActiveTask] = useState(null);
  const [activePhysicalActivity, setActivePhysicalActivity] = useState(null);
  const [patientTab, setPatientTab] = useState("home");
  const [isVoiceOpen, setIsVoiceOpen] = useState(false);
  const [isCaregiverCallOpen, setIsCaregiverCallOpen] = useState(false);
  const handleUpdateProfile = (updated) => {
    setProfile((prev) => ({ ...prev, ...updated }));
  };
  const handleCompleteGame = (taskId, score, accuracy, timeSpentSeconds, errors) => {
    setTasks(
      (prev) => prev.map(
        (t) => t.id === taskId ? {
          ...t,
          status: "completed",
          score,
          accuracy,
          timeSpentSeconds,
          errors
        } : t
      )
    );
    setProfile((prev) => ({
      ...prev,
      activitiesCompletedThisWeek: (prev.activitiesCompletedThisWeek || 14) + 1
    }));
  };
  const handleCompletePhysicalActivity = (activityId, durationSeconds, reps) => {
    const mins = Math.max(1, Math.round(durationSeconds / 60));
    setPhysicalActivities(
      (prev) => prev.map(
        (act) => act.id === activityId ? {
          ...act,
          status: "completed",
          completedAt: (/* @__PURE__ */ new Date()).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
          durationMinutes: mins,
          repetitions: reps || act.repetitions
        } : act
      )
    );
    setProfile((prev) => ({
      ...prev,
      activitiesCompletedThisWeek: (prev.activitiesCompletedThisWeek || 14) + 1
    }));
  };
  const handleLaunchGameByTitle = (title) => {
    const matched = tasks.find((t) => t.title.toLowerCase().includes(title.toLowerCase())) || {
      id: `task-${title.toLowerCase().replace(/\s+/g, "-")}`,
      title: title.toUpperCase(),
      domain: "Memory",
      difficulty: "Easy",
      durationMinutes: 5,
      doctorAssigned: true,
      status: "pending",
      iconName: "Brain",
      description: `Play and enjoy ${title} at a gentle, soothing pace.`,
      required: true
    };
    setActiveTask(matched);
  };
  const handleToggleReminder = (id) => {
    setReminders(
      (prev) => prev.map((r) => r.id === id ? { ...r, completed: !r.completed } : r)
    );
  };
  const handleAddObservation = (newNote) => {
    setNotes((prev) => [newNote, ...prev]);
  };
  const handleAddDoctorNote = (newNote) => {
    setNotes((prev) => [newNote, ...prev]);
  };
  const handleAcknowledgeAlert = (alertId) => {
    setAlertData((prev) => ({ ...prev, isAcknowledged: true }));
  };
  const handleVoiceCommand = (command) => {
    const cmd = command.toLowerCase();
    if (cmd.includes("walk") || cmd.includes("stretch") || cmd.includes("exercise") || cmd.includes("sit to stand") || cmd.includes("breathe") || cmd.includes("wellness")) {
      setIsVoiceOpen(false);
      setCurrentRole("patient");
      const matchedAct = physicalActivities.find(
        (p) => cmd.includes("walk") && p.id === "phys-walk" || cmd.includes("stand") && p.id === "phys-stand" || cmd.includes("hand") && p.id === "phys-hand" || cmd.includes("breath") && p.id === "phys-breath" || cmd.includes("stretch") && p.id === "phys-stretch"
      ) || physicalActivities[0];
      setActivePhysicalActivity(matchedAct);
    } else if (cmd.includes("offline")) {
      setIsVoiceOpen(false);
      setCurrentRole("patient");
      setPatientTab("offline_games");
    } else if (cmd.includes("start") || cmd.includes("game") || cmd.includes("meditation")) {
      setIsVoiceOpen(false);
      const nextPending = tasks.find((t) => t.status !== "completed") || tasks[0];
      setActiveTask(nextPending);
    } else if (cmd.includes("analysis") || cmd.includes("progress")) {
      setIsVoiceOpen(false);
      setCurrentRole("patient");
      setPatientTab("analysis");
    } else if (cmd.includes("caregiver") || cmd.includes("call") || cmd.includes("help")) {
      setIsVoiceOpen(false);
      setIsCaregiverCallOpen(true);
    } else {
      setIsVoiceOpen(false);
    }
  };
  const fontScaleClass = profile.fontSizeScale === "extra-large" ? "text-[19px]" : profile.fontSizeScale === "large" ? "text-[17px]" : "text-[15px]";
  return <div className={`min-h-screen flex flex-col bg-[#F3F8F7] ${fontScaleClass} font-sans transition-all`}>
      
      {
    /* Top Universal Navbar */
  }
      <Header
    currentRole={currentRole}
    onRoleChange={(role) => {
      setActiveTask(null);
      setCurrentRole(role);
    }}
    profile={profile}
    onProfileUpdate={handleUpdateProfile}
    onOpenVoice={() => setIsVoiceOpen(true)}
    onOpenCaregiverCall={() => setIsCaregiverCallOpen(true)}
  />

      {
    /* Main Role Content View */
  }
      <main className="flex-1">
        
        {
    /* ================= 1. MULTI-FRAME SHOWCASE (DEFAULT HERO VIEW) ================= */
  }
        {currentRole === "showcase" && <MultiFrameShowcase
    onSelectRole={(role) => {
      setActiveTask(null);
      setCurrentRole(role);
    }}
    onLaunchGame={(title) => {
      handleLaunchGameByTitle(title);
    }}
  />}

        {
    /* ================= 2. PATIENT VIEW ================= */
  }
        {currentRole === "patient" && <>
            {activePhysicalActivity ? <PhysicalActivityEngine
    activity={activePhysicalActivity}
    profile={profile}
    onComplete={handleCompletePhysicalActivity}
    onBack={() => setActivePhysicalActivity(null)}
  /> : activeTask ? activeTask.id.startsWith("pm-") || ["Coordination", "Rhythm", "Sequencing"].includes(activeTask.domain) || activeTask.title.toLowerCase().includes("touch the body") || activeTask.title.toLowerCase().includes("remember & move") || activeTask.title.toLowerCase().includes("simon says") || activeTask.title.toLowerCase().includes("cross-body") || activeTask.title.toLowerCase().includes("count & touch") || activeTask.title.toLowerCase().includes("left or right") || activeTask.title.toLowerCase().includes("finger sequence") || activeTask.title.toLowerCase().includes("clap pattern") || activeTask.title.toLowerCase().includes("foot tap") || activeTask.title.toLowerCase().includes("movement sequence") || activeTask.title.toLowerCase().includes("color movement") || activeTask.title.toLowerCase().includes("freeze & move") || activeTask.title.toLowerCase().includes("rhythm copy") || activeTask.title.toLowerCase().includes("mirror me") || activeTask.title.toLowerCase().includes("reverse sequence") ? <PhysicalMemoryEngine
    game={activeTask}
    profile={profile}
    onComplete={handleCompleteGame}
    onBack={() => setActiveTask(null)}
  /> : <AllGamesEngine
    task={activeTask}
    profile={profile}
    onComplete={handleCompleteGame}
    onBack={() => setActiveTask(null)}
  /> : patientTab === "offline_games" ? <OfflineGamesCenter
    profile={profile}
    onBack={() => setPatientTab("home")}
    onRecordPerformance={() => {
    }}
  /> : patientTab === "tasks" ? <PatientTasks
    tasks={tasks}
    profile={profile}
    onStartTask={(task) => setActiveTask(task)}
    onBack={() => setPatientTab("home")}
  /> : patientTab === "games" ? <PatientFreePlay
    games={freePlayGames}
    profile={profile}
    onStartGame={(task) => setActiveTask(task)}
    onBack={() => setPatientTab("home")}
  /> : patientTab === "progress" ? <PatientProgress
    profile={profile}
    performance={performance}
    onBack={() => setPatientTab("home")}
  /> : patientTab === "analysis" ? <PatientAIAnalysis
    profile={profile}
    onBack={() => setPatientTab("home")}
    onNavigateTab={(tab) => {
      if (tab === "help") setIsCaregiverCallOpen(true);
      else setPatientTab(tab);
    }}
  /> : <PatientHome
    profile={profile}
    tasks={tasks}
    physicalActivities={physicalActivities}
    freePlayGames={freePlayGames}
    reminders={reminders}
    performance={performance}
    onStartTask={(task) => setActiveTask(task)}
    onStartPhysicalActivity={(act) => setActivePhysicalActivity(act)}
    onOpenOfflineCenter={() => setPatientTab("offline_games")}
    onOpenVoice={() => setIsVoiceOpen(true)}
    onOpenCaregiverCall={() => setIsCaregiverCallOpen(true)}
    onToggleReminder={handleToggleReminder}
    onNavigateTab={(tab) => {
      if (tab === "help") setIsCaregiverCallOpen(true);
      else if (tab === "offline_games" || tab === "physical") setPatientTab(tab);
      else setPatientTab(tab);
    }}
  />}
          </>}

        {
    /* ================= 3. DESKTOP VIEW ================= */
  }
        {currentRole === "desktop" && <DesktopLayout
    profile={profile}
    tasks={tasks}
    freePlayGames={freePlayGames}
    reminders={reminders}
    performance={performance}
    onStartTask={(task) => setActiveTask(task)}
    onOpenVoice={() => setIsVoiceOpen(true)}
    onOpenCaregiverCall={() => setIsCaregiverCallOpen(true)}
  />}

        {
    /* ================= 4. FAMILY VIEW ================= */
  }
        {currentRole === "family" && <FamilyDashboard
    profile={profile}
    tasks={tasks}
    reminders={reminders}
    performance={performance}
    alert={alertData}
    notes={notes}
    onAddObservation={handleAddObservation}
    onContactDoctor={() => {
      alert(`Connecting to ${profile.doctorName} at ${profile.doctorHospital}...`);
    }}
  />}

        {
    /* ================= 5. DOCTOR VIEW ================= */
  }
        {currentRole === "doctor" && <DoctorDashboard
    profile={profile}
    tasks={tasks}
    reminders={reminders}
    performance={performance}
    alert={alertData}
    notes={notes}
    onUpdateTasks={setTasks}
    onAcknowledgeAlert={handleAcknowledgeAlert}
    onAddClinicalNote={handleAddDoctorNote}
  />}

        {
    /* Active game when launched from any non-patient view */
  }
        {currentRole !== "patient" && activeTask && <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
            <div className="bg-[#F3F8F7] rounded-3xl w-full max-w-lg p-2 max-h-[95vh] overflow-y-auto">
              <AllGamesEngine
    task={activeTask}
    profile={profile}
    onComplete={handleCompleteGame}
    onBack={() => setActiveTask(null)}
  />
            </div>
          </div>}

      </main>

      {
    /* Voice Assistant Modal (Frame 10) */
  }
      <VoiceModal
    isOpen={isVoiceOpen}
    onClose={() => setIsVoiceOpen(false)}
    profile={profile}
    onCommandTrigger={handleVoiceCommand}
  />

      {
    /* Direct Caregiver Call Modal */
  }
      <CallCaregiverModal
    isOpen={isCaregiverCallOpen}
    onClose={() => setIsCaregiverCallOpen(false)}
    profile={profile}
  />

    </div>;
}
