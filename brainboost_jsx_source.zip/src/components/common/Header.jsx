import { translations } from "../../data/translations";
import { BrainBoostLogo } from "./GraphicAssets";
import {
  Volume2,
  Phone,
  Wifi,
  WifiOff,
  Globe,
  User,
  Users,
  Stethoscope,
  LayoutGrid
} from "lucide-react";
export const Header = ({
  currentRole,
  onRoleChange,
  profile,
  onProfileUpdate,
  onOpenVoice,
  onOpenCaregiverCall
}) => {
  const t = translations[profile.language];
  const handleSpeakGreeting = () => {
    if ("speechSynthesis" in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(t.greetingMorning + ". " + t.voicePrompt);
      utterance.rate = 0.9;
      utterance.pitch = 1;
      window.speechSynthesis.speak(utterance);
    }
  };
  return <header className="sticky top-0 z-40 bg-white/95 backdrop-blur border-b border-[#0D7377]/15 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          
          {
    /* Logo & Brand */
  }
          <div className="flex items-center gap-3">
            <button
    onClick={() => onRoleChange("patient")}
    className="flex items-center gap-2.5 text-left group transition"
  >
              <BrainBoostLogo iconSize="w-9 h-9" textSize="text-xl sm:text-2xl" />
            </button>
          </div>

          {
    /* Role Navigation Switcher Pills */
  }
          <div className="hidden lg:flex items-center p-1 bg-[#F0F7F6] rounded-2xl border border-[#0D7377]/15 shadow-inner">
            <button
    id="role-btn-patient"
    onClick={() => onRoleChange("patient")}
    className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-sm font-bold transition-all ${currentRole === "patient" ? "bg-[#0D7377] text-white shadow-sm" : "text-[#132A2F]/70 hover:text-[#132A2F] hover:bg-white/60"}`}
  >
              <User className="w-4 h-4" />
              Patient View
            </button>

            <button
    id="role-btn-family"
    onClick={() => onRoleChange("family")}
    className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-sm font-bold transition-all ${currentRole === "family" ? "bg-[#0D7377] text-white shadow-sm" : "text-[#132A2F]/70 hover:text-[#132A2F] hover:bg-white/60"}`}
  >
              <Users className="w-4 h-4" />
              Family View
            </button>

            <button
    id="role-btn-doctor"
    onClick={() => onRoleChange("doctor")}
    className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-sm font-bold transition-all ${currentRole === "doctor" ? "bg-[#0D7377] text-white shadow-sm" : "text-[#132A2F]/70 hover:text-[#132A2F] hover:bg-white/60"}`}
  >
              <Stethoscope className="w-4 h-4" />
              Doctor Clinical
            </button>

            <button
    id="role-btn-showcase"
    onClick={() => onRoleChange("showcase")}
    className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-sm font-bold transition-all ${currentRole === "showcase" ? "bg-amber-600 text-white shadow-sm" : "text-amber-800/80 hover:text-amber-900 hover:bg-amber-50"}`}
  >
              <LayoutGrid className="w-4 h-4 text-amber-300" />
              Multi-Frame Showcase
            </button>
          </div>

          {
    /* Quick Actions & Accessibility Controls */
  }
          <div className="flex items-center gap-2 sm:gap-3">
            
            {
    /* Language Selector */
  }
            <div className="relative group">
              <select
    value={profile.language}
    onChange={(e) => onProfileUpdate({ language: e.target.value })}
    className="appearance-none bg-[#F0F7F6] hover:bg-[#E5F2F0] text-[#132A2F] font-semibold text-xs sm:text-sm pl-8 pr-7 py-2 rounded-xl border border-[#0D7377]/20 focus:outline-none focus:ring-2 focus:ring-[#0D7377] cursor-pointer transition"
    title="Select Language"
  >
                <option value="en">English (EN)</option>
                <option value="hi">हिन्दी (Hindi)</option>
                <option value="as">অসমীয়া (Assamese)</option>
                <option value="bn">বাংলা (Bengali)</option>
                <option value="mni">মৈতৈলোন্ (Manipuri)</option>
                <option value="lus">Mizo ṭawng</option>
              </select>
              <Globe className="w-4 h-4 text-[#0D7377] absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>

            {
    /* Voice Assistant Read Aloud Button */
  }
            <button
    id="btn-header-voice"
    onClick={() => {
      handleSpeakGreeting();
      onOpenVoice();
    }}
    className="flex items-center gap-1.5 bg-[#E8F6F4] hover:bg-[#D4EFEA] text-[#0D7377] font-bold px-3 py-2 rounded-xl border border-[#0D7377]/25 text-xs sm:text-sm transition shadow-xs active:scale-95"
    title="Activate Voice Assistant"
  >
              <Volume2 className="w-4 h-4 text-[#0D7377]" />
              <span className="hidden sm:inline">Voice</span>
            </button>

            {
    /* Emergency / Fast Caregiver Connect Button */
  }
            <button
    id="btn-call-caregiver-top"
    onClick={onOpenCaregiverCall}
    className="flex items-center gap-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold px-3 py-2 rounded-xl border border-rose-200 text-xs sm:text-sm transition shadow-xs active:scale-95"
    title="Call Caregiver"
  >
              <Phone className="w-4 h-4 text-rose-600" />
              <span className="hidden md:inline">Caregiver</span>
            </button>

            {
    /* Offline Simulation Switcher */
  }
            <button
    onClick={() => onProfileUpdate({ isOffline: !profile.isOffline })}
    className={`p-2 rounded-xl border text-xs font-semibold transition flex items-center gap-1 ${profile.isOffline ? "bg-amber-100 border-amber-300 text-amber-800" : "bg-emerald-50 border-emerald-200 text-emerald-700"}`}
    title={profile.isOffline ? "Currently in Offline Mode" : "Online Mode (Click to test Offline Mode)"}
  >
              {profile.isOffline ? <>
                  <WifiOff className="w-4 h-4 text-amber-700" />
                  <span className="hidden xl:inline text-xs">Offline</span>
                </> : <>
                  <Wifi className="w-4 h-4 text-emerald-600" />
                  <span className="hidden xl:inline text-xs">Online</span>
                </>}
            </button>

            {
    /* Font Size Toggle for Elderly View */
  }
            <button
    onClick={() => {
      const next = profile.fontSizeScale === "standard" ? "large" : profile.fontSizeScale === "large" ? "extra-large" : "standard";
      onProfileUpdate({ fontSizeScale: next });
    }}
    className="p-2 bg-[#F0F7F6] hover:bg-[#E5F2F0] rounded-xl border border-[#0D7377]/20 text-[#132A2F] text-xs font-bold transition flex items-center gap-1"
    title={`Text Size: ${profile.fontSizeScale}`}
  >
              <span className="text-[13px] font-black text-[#0D7377]">A</span>
              <span className="text-[16px] font-black text-[#0D7377]">A+</span>
            </button>

          </div>
        </div>

        {
    /* Mobile Sub-Navbar for Quick Role Switch */
  }
        <div className="flex lg:hidden py-2 gap-1.5 overflow-x-auto border-t border-slate-100">
          <button
    onClick={() => onRoleChange("patient")}
    className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition ${currentRole === "patient" ? "bg-[#0D7377] text-white" : "bg-slate-100 text-slate-700"}`}
  >
            Patient
          </button>
          <button
    onClick={() => onRoleChange("family")}
    className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition ${currentRole === "family" ? "bg-[#0D7377] text-white" : "bg-slate-100 text-slate-700"}`}
  >
            Family
          </button>
          <button
    onClick={() => onRoleChange("doctor")}
    className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition ${currentRole === "doctor" ? "bg-[#0D7377] text-white" : "bg-slate-100 text-slate-700"}`}
  >
            Doctor
          </button>
          <button
    onClick={() => onRoleChange("showcase")}
    className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition ${currentRole === "showcase" ? "bg-amber-600 text-white" : "bg-amber-100 text-amber-900"}`}
  >
            Showcase Board
          </button>
        </div>

      </div>
    </header>;
};
