import { useState } from "react";
import { sessionHistoryRecords } from "../../data/initialData";
import {
  Stethoscope,
  Brain,
  Sparkles,
  AlertTriangle,
  Calendar,
  Clock,
  CheckCircle2,
  Plus,
  Trash2,
  ArrowRight,
  FileText,
  Activity,
  Check,
  Phone,
  Printer,
  ChevronRight,
  BarChart3
} from "lucide-react";
export const DoctorDashboard = ({
  profile,
  tasks,
  reminders,
  performance,
  alert,
  notes,
  onUpdateTasks,
  onAcknowledgeAlert,
  onAddClinicalNote
}) => {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [searchTerm, setSearchTerm] = useState("Lakshmi Devi");
  const [selectedPatient, setSelectedPatient] = useState("Lakshmi Devi");
  const [isAlertAcknowledged, setIsAlertAcknowledged] = useState(alert.isAcknowledged);
  const [timelineTasks, setTimelineTasks] = useState(tasks);
  const [aiPlanApproved, setAiPlanApproved] = useState(false);
  const [showAddTaskModal, setShowAddTaskModal] = useState(false);
  const [newTaskTitle, setNewTaskTitle] = useState("Object Recall");
  const [newTaskDomain, setNewTaskDomain] = useState("Recall");
  const [newTaskTime, setNewTaskTime] = useState("14:00");
  const [newTaskDifficulty, setNewTaskDifficulty] = useState("Easy");
  const [historyFilterDomain, setHistoryFilterDomain] = useState("all");
  const [newClinicalNote, setNewClinicalNote] = useState("");
  const [simulationScenario, setSimulationScenario] = useState("decline");
  const currentPerformance = simulationScenario === "improvement" ? [
    { day: "Day 1", date: "19 Aug", memory: 72, attention: 75, recall: 70, pattern: 74, overall: 73, baseline: 80, timeMinutesEasy: 6.5, timeMinutesMed: 9, errorsCount: 6 },
    { day: "Day 2", date: "20 Aug", memory: 75, attention: 78, recall: 73, pattern: 76, overall: 76, baseline: 80, timeMinutesEasy: 5.8, timeMinutesMed: 8.5, errorsCount: 5 },
    { day: "Day 3", date: "21 Aug", memory: 79, attention: 82, recall: 77, pattern: 80, overall: 80, baseline: 80, timeMinutesEasy: 5, timeMinutesMed: 7.8, errorsCount: 4 },
    { day: "Day 4", date: "22 Aug", memory: 82, attention: 85, recall: 81, pattern: 84, overall: 83, baseline: 80, timeMinutesEasy: 4.5, timeMinutesMed: 7.2, errorsCount: 3 },
    { day: "Day 5", date: "23 Aug", memory: 85, attention: 88, recall: 84, pattern: 87, overall: 86, baseline: 80, timeMinutesEasy: 4, timeMinutesMed: 6.8, errorsCount: 2 },
    { day: "Day 6", date: "24 Aug", memory: 87, attention: 89, recall: 86, pattern: 89, overall: 88, baseline: 80, timeMinutesEasy: 3.8, timeMinutesMed: 6.4, errorsCount: 1 },
    { day: "Day 7 (Today)", date: "25 Aug", memory: 89, attention: 91, recall: 88, pattern: 92, overall: 90, baseline: 80, timeMinutesEasy: 3.5, timeMinutesMed: 6, errorsCount: 1 }
  ] : simulationScenario === "dip" ? [
    { day: "Day 1", date: "19 Aug", memory: 88, attention: 89, recall: 86, pattern: 90, overall: 88, baseline: 88, timeMinutesEasy: 3.5, timeMinutesMed: 6.5, errorsCount: 2 },
    { day: "Day 2", date: "20 Aug", memory: 89, attention: 88, recall: 87, pattern: 91, overall: 89, baseline: 88, timeMinutesEasy: 3.4, timeMinutesMed: 6.4, errorsCount: 2 },
    { day: "Day 3", date: "21 Aug", memory: 87, attention: 90, recall: 85, pattern: 89, overall: 88, baseline: 88, timeMinutesEasy: 3.6, timeMinutesMed: 6.6, errorsCount: 2 },
    { day: "Day 4", date: "22 Aug", memory: 88, attention: 87, recall: 86, pattern: 90, overall: 88, baseline: 88, timeMinutesEasy: 3.5, timeMinutesMed: 6.5, errorsCount: 2 },
    { day: "Day 5", date: "23 Aug", memory: 86, attention: 88, recall: 84, pattern: 89, overall: 87, baseline: 88, timeMinutesEasy: 3.8, timeMinutesMed: 6.8, errorsCount: 3 },
    { day: "Day 6 (Poor Sleep)", date: "24 Aug", memory: 62, attention: 74, recall: 58, pattern: 78, overall: 68, baseline: 88, timeMinutesEasy: 6.2, timeMinutesMed: 9, errorsCount: 7 },
    { day: "Day 7 (Recovered)", date: "25 Aug", memory: 88, attention: 89, recall: 87, pattern: 91, overall: 89, baseline: 88, timeMinutesEasy: 3.5, timeMinutesMed: 6.5, errorsCount: 2 }
  ] : performance;
  const handleAddNewTask = (e) => {
    e.preventDefault();
    const newTask = {
      id: `task-${Date.now()}`,
      title: newTaskTitle.toUpperCase(),
      domain: newTaskDomain,
      difficulty: newTaskDifficulty,
      durationMinutes: 4,
      doctorAssigned: true,
      assignedTime: newTaskTime,
      status: "pending",
      iconName: "Eye",
      description: "Prescribed cognitive exercise.",
      required: true
    };
    const updated = [...timelineTasks, newTask].sort((a, b) => (a.assignedTime || "").localeCompare(b.assignedTime || ""));
    setTimelineTasks(updated);
    onUpdateTasks(updated);
    setShowAddTaskModal(false);
  };
  const handleRemoveTask = (id) => {
    const updated = timelineTasks.filter((t) => t.id !== id);
    setTimelineTasks(updated);
    onUpdateTasks(updated);
  };
  const handleChangeDifficulty = (id, diff) => {
    const updated = timelineTasks.map((t) => t.id === id ? { ...t, difficulty: diff } : t);
    setTimelineTasks(updated);
    onUpdateTasks(updated);
  };
  const handleApproveAiPlan = () => {
    setAiPlanApproved(true);
    const updated = timelineTasks.map((t) => ({ ...t, difficulty: "Easy" }));
    setTimelineTasks(updated);
    onUpdateTasks(updated);
  };
  const handleSaveDoctorNote = (e) => {
    e.preventDefault();
    if (!newClinicalNote.trim()) return;
    const noteItem = {
      id: `doc-note-${Date.now()}`,
      date: "25 Aug 2026",
      author: profile.doctorName,
      authorRole: "doctor",
      category: "Clinical",
      content: newClinicalNote,
      followUpRequired: true
    };
    onAddClinicalNote(noteItem);
    setNewClinicalNote("");
  };
  const filteredHistory = historyFilterDomain === "all" ? sessionHistoryRecords : sessionHistoryRecords.filter((s) => s.domain.toLowerCase() === historyFilterDomain.toLowerCase());
  return <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6 pb-24">
      
      {
    /* Top Doctor Bar (Frame 46: DESIGN OF DASHBOARD TOP AREA) */
  }
      <div className="bg-white rounded-3xl p-6 sm:p-7 shadow-xs border border-[#0D7377]/15">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-[#0D7377] text-white flex items-center justify-center shrink-0 shadow-md shadow-[#0D7377]/20">
              <Stethoscope className="w-8 h-8 text-[#9DF3C4]" />
            </div>
            <div>
              <div className="flex items-center gap-3 flex-wrap">
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                  Active Patient:
                </span>
                <h1 className="text-2xl sm:text-3xl font-extrabold text-[#132A2F] font-display">
                  {profile.name}
                </h1>
                <span className="text-xs font-bold bg-teal-100 text-teal-800 px-3 py-0.5 rounded-full">
                  Age {profile.age}
                </span>
                <span className="text-xs font-bold bg-amber-100 text-amber-800 border border-amber-300 px-3 py-0.5 rounded-full flex items-center gap-1">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  1 Alert Active
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-500 font-medium mt-1">
                Last Active: Today 5:30 PM · Tasks: 3/4 complete · AI: Memory trend below baseline (88% → 68%)
              </p>
            </div>
          </div>

          {
    /* Quick Doctor Navigation Tabs */
  }
          <div className="flex items-center gap-1.5 overflow-x-auto p-1.5 bg-[#F0F7F6] rounded-2xl border border-[#0D7377]/15">
            {[
    { id: "dashboard", label: "Dashboard", icon: BarChart3 },
    { id: "scheduler", label: "Task Scheduler", icon: Calendar },
    { id: "analytics", label: "AI Analytics", icon: Activity },
    { id: "alerts", label: "Alert Center", icon: AlertTriangle, badge: "1" },
    { id: "history", label: "Session History", icon: Clock },
    { id: "notes", label: "Clinical Notes", icon: FileText },
    { id: "reports", label: "Weekly Report", icon: Printer }
  ].map((tab) => {
    const Icon = tab.icon;
    const isCurrent = activeTab === tab.id;
    return <button
      key={tab.id}
      onClick={() => setActiveTab(tab.id)}
      className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition ${isCurrent ? "bg-[#0D7377] text-white shadow-xs" : "text-slate-700 hover:bg-white/80"}`}
    >
                  <Icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                  {tab.badge && <span className="w-4 h-4 rounded-full bg-rose-500 text-white text-[10px] flex items-center justify-center font-black">
                      {tab.badge}
                    </span>}
                </button>;
  })}
          </div>

        </div>
      </div>

      {
    /* ========================================================= */
  }
      {
    /* SIH AI CLINICAL DEMONSTRATOR BAR (Section 61, 62, 63) */
  }
      {
    /* ========================================================= */
  }
      <div className="bg-gradient-to-r from-[#132A2F] to-[#0D7377] rounded-3xl p-4 sm:p-5 text-white shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-white/10 flex items-center justify-center text-[#9DF3C4]">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] font-black uppercase tracking-widest text-[#9DF3C4] block">
              AI ENGINE LONGITUDINAL SIMULATOR
            </span>
            <p className="text-xs sm:text-sm font-extrabold text-white">
              {simulationScenario === "decline" ? "Scenario 1: Persistent Decline Detected (4 Consecutive Sessions Below Baseline)" : simulationScenario === "improvement" ? "Scenario 2: Adaptive Cognitive Improvement (AI Proposes Difficulty Upgrade)" : "Scenario 3: Temporary Sleep Dip / Filtered False Alert (Responsible Alerting)"}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
    onClick={() => setSimulationScenario("decline")}
    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${simulationScenario === "decline" ? "bg-amber-400 text-slate-950 shadow-xs" : "bg-white/10 hover:bg-white/20 text-white"}`}
  >
            Scenario 1: Persistent Decline
          </button>
          <button
    onClick={() => setSimulationScenario("improvement")}
    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${simulationScenario === "improvement" ? "bg-emerald-400 text-slate-950 shadow-xs" : "bg-white/10 hover:bg-white/20 text-white"}`}
  >
            Scenario 2: Improvement
          </button>
          <button
    onClick={() => setSimulationScenario("dip")}
    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${simulationScenario === "dip" ? "bg-blue-400 text-slate-950 shadow-xs" : "bg-white/10 hover:bg-white/20 text-white"}`}
  >
            Scenario 3: Isolated Dip
          </button>
        </div>
      </div>

      {
    /* ========================================================= */
  }
      {
    /* TAB 1: MAIN DOCTOR CLINICAL DASHBOARD (Frame 12) */
  }
      {
    /* ========================================================= */
  }
      {activeTab === "dashboard" && <div className="space-y-6 animate-in fade-in duration-200">
          
          {
    /* Top Metric Cards (Frame 12) */
  }
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            
            <div className="bg-white rounded-3xl p-5 sm:p-6 shadow-xs border border-[#0D7377]/15">
              <span className="text-xs font-bold text-slate-500 uppercase block mb-1">Task Completion</span>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-extrabold text-[#132A2F]">86%</span>
                <span className="text-xs font-bold text-emerald-700">18/21 week</span>
              </div>
              <div className="w-full bg-slate-100 h-2 rounded-full mt-3 overflow-hidden">
                <div className="bg-[#0D7377] h-full rounded-full" style={{ width: "86%" }} />
              </div>
            </div>

            <div className="bg-white rounded-3xl p-5 sm:p-6 shadow-xs border border-[#0D7377]/15">
              <span className="text-xs font-bold text-slate-500 uppercase block mb-1">Average Score</span>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-extrabold text-[#132A2F]">76%</span>
                <span className="text-xs font-bold text-amber-700">vs 88% Base</span>
              </div>
              <p className="text-[11px] text-slate-500 mt-2">Consistent engagement</p>
            </div>

            <div className="bg-white rounded-3xl p-5 sm:p-6 shadow-xs border border-[#0D7377]/15">
              <span className="text-xs font-bold text-amber-800 uppercase block mb-1">Memory Accuracy</span>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-extrabold text-amber-700">68%</span>
                <span className="text-xs font-bold text-amber-800 bg-amber-100 px-2 py-0.5 rounded-md">
                  ↓ -20%
                </span>
              </div>
              <p className="text-[11px] text-slate-500 mt-2">4 sessions below baseline</p>
            </div>

            <div className="bg-amber-50 rounded-3xl p-5 sm:p-6 shadow-xs border-2 border-amber-300">
              <span className="text-xs font-bold text-amber-900 uppercase block mb-1">Active Alerts</span>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-black text-amber-900">1</span>
                <span className="text-xs font-bold text-amber-800">Persistent Change</span>
              </div>
              <button
    onClick={() => setActiveTab("alerts")}
    className="text-xs font-bold text-amber-900 underline mt-2 inline-flex items-center gap-1"
  >
                Review Evidence <ArrowRight className="w-3 h-3" />
              </button>
            </div>

          </div>

          {
    /* Main Trend Line + AI Longitudinal Analysis */
  }
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {
    /* Cognitive Performance Trend (Frame 16) */
  }
            <div className="lg:col-span-2 bg-white rounded-3xl p-6 sm:p-7 shadow-xs border border-[#0D7377]/15">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-6">
                <div>
                  <h3 className="text-xl font-extrabold text-[#132A2F]">
                    Cognitive Performance Trend (7 Days)
                  </h3>
                  <p className="text-xs text-slate-500 font-medium">
                    Memory, Attention, Recall, and Pattern vs Personal Baseline (88%)
                  </p>
                </div>
                <div className="flex items-center gap-3 text-xs font-bold">
                  <span className="text-amber-600 flex items-center gap-1">
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-500" /> Memory
                  </span>
                  <span className="text-emerald-600 flex items-center gap-1">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" /> Attention
                  </span>
                  <span className="text-[#0D7377] flex items-center gap-1">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#0D7377]" /> Pattern
                  </span>
                </div>
              </div>

              {
    /* Clean SVG Line Graph with Tooltips */
  }
              <div className="w-full overflow-x-auto">
                <svg viewBox="0 0 600 230" className="w-full h-60">
                  {
    /* Horizontal Grid */
  }
                  {[100, 80, 60, 40].map((v) => {
    const y = 30 + (100 - v) / 60 * 150;
    return <g key={v}>
                        <line x1="40" y1={y} x2="570" y2={y} stroke="#F1F5F9" strokeWidth="1" strokeDasharray="3 3" />
                        <text x="30" y={y + 4} textAnchor="end" fontSize="10" fill="#94A3B8" fontWeight="bold">
                          {v}%
                        </text>
                      </g>;
  })}

                  {
    /* Baseline 88% */
  }
                  {(() => {
    const baseY = 30 + (100 - 88) / 60 * 150;
    return <g>
                        <line x1="40" y1={baseY} x2="570" y2={baseY} stroke="#148A85" strokeWidth="1.5" strokeDasharray="4 4" />
                        <text x="560" y={baseY - 5} textAnchor="end" fontSize="10" fill="#0D7377" fontWeight="bold">
                          Baseline: 88%
                        </text>
                      </g>;
  })()}

                  {
    /* Memory Series (Amber) */
  }
                  {(() => {
    const pts = currentPerformance.map((p, i) => {
      const x = 50 + i * 510 / (currentPerformance.length - 1);
      const y = 30 + (100 - p.memory) / 60 * 150;
      return `${x},${y}`;
    }).join(" ");
    return <polyline points={pts} fill="none" stroke="#F59E0B" strokeWidth="3" strokeLinecap="round" />;
  })()}

                  {
    /* Attention Series (Emerald) */
  }
                  {(() => {
    const pts = currentPerformance.map((p, i) => {
      const x = 50 + i * 510 / (currentPerformance.length - 1);
      const y = 30 + (100 - p.attention) / 60 * 150;
      return `${x},${y}`;
    }).join(" ");
    return <polyline points={pts} fill="none" stroke="#10B981" strokeWidth="2.5" strokeLinecap="round" />;
  })()}

                  {
    /* Pattern Series (Teal) */
  }
                  {(() => {
    const pts = currentPerformance.map((p, i) => {
      const x = 50 + i * 510 / (currentPerformance.length - 1);
      const y = 30 + (100 - p.pattern) / 60 * 150;
      return `${x},${y}`;
    }).join(" ");
    return <polyline points={pts} fill="none" stroke="#0D7377" strokeWidth="2" strokeDasharray="3 3" strokeLinecap="round" />;
  })()}

                  {
    /* Dots & Labels */
  }
                  {currentPerformance.map((p, i) => {
    const x = 50 + i * 510 / (currentPerformance.length - 1);
    const yMem = 30 + (100 - p.memory) / 60 * 150;
    return <g key={i}>
                        <circle cx={x} cy={yMem} r="5" fill="#FFFFFF" stroke="#F59E0B" strokeWidth="3" />
                        <text x={x} y="210" textAnchor="middle" fontSize="10" fontWeight="bold" fill="#64748B">
                          {p.date}
                        </text>
                        {i === currentPerformance.length - 1 && <text x={x} y={yMem - 10} textAnchor="middle" fontSize="11" fontWeight="extrabold" fill="#B45309">
                            {p.memory}% (Today)
                          </text>}
                      </g>;
  })}
                </svg>
              </div>
            </div>

            {
    /* AI Analysis Panel (Frame 15 & 21) */
  }
            <div className="bg-white rounded-3xl p-6 sm:p-7 shadow-xs border border-[#0D7377]/15 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2.5 mb-4">
                  <div className="w-10 h-10 rounded-2xl bg-[#0D7377] text-white flex items-center justify-center">
                    <Brain className="w-5 h-5 text-[#9DF3C4]" />
                  </div>
                  <div>
                    <h3 className="text-lg font-extrabold text-[#132A2F]">
                      AI Longitudinal Rationale
                    </h3>
                    <p className="text-xs text-slate-500 font-medium">Explainable Machine Intelligence</p>
                  </div>
                </div>

                <div className={`rounded-2xl p-4 border mb-4 ${simulationScenario === "decline" ? "bg-amber-50/80 border-amber-200" : simulationScenario === "improvement" ? "bg-emerald-50/80 border-emerald-200" : "bg-blue-50/80 border-blue-200"}`}>
                  <div className="flex items-center gap-2 font-extrabold text-xs mb-1">
                    <AlertTriangle className={`w-4 h-4 ${simulationScenario === "decline" ? "text-amber-700" : simulationScenario === "improvement" ? "text-emerald-700" : "text-blue-700"}`} />
                    <span className={simulationScenario === "decline" ? "text-amber-900" : simulationScenario === "improvement" ? "text-emerald-900" : "text-blue-900"}>
                      {simulationScenario === "decline" ? "PERSISTENT PERFORMANCE CHANGE" : simulationScenario === "improvement" ? "STEADY COGNITIVE IMPROVEMENT" : "TRANSIENT DEVIATION FILTERED"}
                    </span>
                  </div>
                  <p className="text-xs text-slate-700 font-medium leading-relaxed">
                    {simulationScenario === "decline" ? "Memory accuracy dropped from 88% baseline to 68% over 4 comparable sessions. Average completion time shifted from 4.2 min to 7.8 min. Attention remains intact at 86%." : simulationScenario === "improvement" ? "Memory accuracy rose from 72% to 89% over 7 sessions with average completion time improving from 6.5 min to 3.5 min. AI recommends advancing to Medium tier." : "Day 6 dip (62%) was an isolated episode coinciding with caregiver-reported poor sleep. Day 7 performance returned to 88%. No clinical alert triggered (responsible alerting)."}
                  </p>
                </div>

                {
    /* Domain Breakdown Badges */
  }
                <div className="grid grid-cols-2 gap-2 text-xs font-bold mb-4">
                  <div className="bg-[#F4F9F8] p-2.5 rounded-xl border border-slate-200">
                    <span className="text-slate-500 block text-[10px]">Memory</span>
                    <span className="text-amber-700 text-sm font-black">
                      {currentPerformance[currentPerformance.length - 1].memory}%
                    </span>
                  </div>
                  <div className="bg-[#F4F9F8] p-2.5 rounded-xl border border-slate-200">
                    <span className="text-slate-500 block text-[10px]">Attention</span>
                    <span className="text-emerald-700 text-sm font-black">
                      {currentPerformance[currentPerformance.length - 1].attention}%
                    </span>
                  </div>
                  <div className="bg-[#F4F9F8] p-2.5 rounded-xl border border-slate-200">
                    <span className="text-slate-500 block text-[10px]">Recall</span>
                    <span className="text-teal-700 text-sm font-black">
                      {currentPerformance[currentPerformance.length - 1].recall}%
                    </span>
                  </div>
                  <div className="bg-[#F4F9F8] p-2.5 rounded-xl border border-slate-200">
                    <span className="text-slate-500 block text-[10px]">Pattern</span>
                    <span className="text-teal-700 text-sm font-black">
                      {currentPerformance[currentPerformance.length - 1].pattern}%
                    </span>
                  </div>
                </div>
              </div>

              <div className="space-y-2 pt-3 border-t border-slate-100">
                <button
    onClick={() => setActiveTab("scheduler")}
    className="w-full py-3 bg-[#0D7377] hover:bg-[#0A5C5F] text-white font-extrabold text-xs sm:text-sm rounded-xl transition flex items-center justify-center gap-2"
  >
                  <Calendar className="w-4 h-4" />
                  Adjust Daily Schedule
                </button>
              </div>
            </div>

          </div>

          {
    /* Bottom: Recent Session Table (Frame 12 & Frame 20 preview) */
  }
          <div className="bg-white rounded-3xl p-6 sm:p-7 shadow-xs border border-[#0D7377]/15">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-xl font-extrabold text-[#132A2F]">
                  Recent Session Logs
                </h3>
                <p className="text-xs text-slate-500 font-medium">Detailed trial logs with time and error metrics</p>
              </div>
              <button
    onClick={() => setActiveTab("history")}
    className="text-xs font-bold text-[#0D7377] hover:underline flex items-center gap-1"
  >
                View Full History <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs sm:text-sm">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500 font-bold uppercase text-[11px]">
                    <th className="pb-3">Date</th>
                    <th className="pb-3">Activity</th>
                    <th className="pb-3">Domain</th>
                    <th className="pb-3">Difficulty</th>
                    <th className="pb-3">Score</th>
                    <th className="pb-3">Accuracy</th>
                    <th className="pb-3">Time</th>
                    <th className="pb-3">Errors</th>
                    <th className="pb-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                  {sessionHistoryRecords.slice(0, 4).map((row) => <tr key={row.id} className="hover:bg-slate-50 transition">
                      <td className="py-3.5 font-bold text-[#132A2F]">{row.date}</td>
                      <td className="py-3.5">{row.game}</td>
                      <td className="py-3.5">
                        <span className="bg-[#EAF6F4] text-[#0D7377] font-bold px-2 py-0.5 rounded-full text-xs">
                          {row.domain}
                        </span>
                      </td>
                      <td className="py-3.5">{row.difficulty}</td>
                      <td className="py-3.5 font-bold">{row.score}</td>
                      <td className="py-3.5 font-extrabold text-[#0D7377]">{row.accuracy}</td>
                      <td className="py-3.5">{row.time}</td>
                      <td className="py-3.5 text-amber-700 font-bold">{row.errors}</td>
                      <td className="py-3.5">
                        <span className="text-emerald-700 font-bold flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Completed
                        </span>
                      </td>
                    </tr>)}
                </tbody>
              </table>
            </div>
          </div>

        </div>}

      {
    /* ========================================================= */
  }
      {
    /* TAB 2: DOCTOR TASK SCHEDULER (Frame 14 & 21) */
  }
      {
    /* ========================================================= */
  }
      {activeTab === "scheduler" && <div className="space-y-6 animate-in fade-in duration-200">
          
          {
    /* AI Recommended Plan Card (Frame 21) */
  }
          <div className="bg-gradient-to-r from-teal-50 to-blue-50 rounded-3xl p-6 sm:p-7 border border-teal-200 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-[#0D7377] text-white flex items-center justify-center">
                  <Brain className="w-6 h-6 text-[#9DF3C4]" />
                </div>
                <div>
                  <span className="text-xs font-bold text-[#0D7377] uppercase tracking-wider block">
                    AI Auto-Tuned Recommendation (Frame 21)
                  </span>
                  <h3 className="text-xl font-black text-[#132A2F]">
                    AI Recommended Plan
                  </h3>
                </div>
              </div>

              {aiPlanApproved ? <div className="flex items-center gap-2 text-emerald-800 bg-emerald-100 font-bold px-4 py-2 rounded-xl border border-emerald-300">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                  Plan Approved & Synced to Patient App
                </div> : <div className="flex gap-2">
                  <button
    onClick={handleApproveAiPlan}
    className="px-5 py-2.5 bg-[#0D7377] hover:bg-[#0A5C5F] text-white font-extrabold text-sm rounded-xl shadow-xs transition"
  >
                    [APPROVE PLAN]
                  </button>
                  <button
    onClick={() => setShowAddTaskModal(true)}
    className="px-4 py-2.5 bg-white hover:bg-slate-50 text-slate-700 font-bold text-sm rounded-xl border border-slate-200 transition"
  >
                    [EDIT]
                  </button>
                </div>}
            </div>

            <p className="text-sm text-slate-700 font-medium mb-3 leading-relaxed">
              <strong>Reason:</strong> "Recent memory performance is below baseline (88% → 68%). Lower cognitive load recommended: keep all morning memory sessions on Easy difficulty with 4-minute time caps."
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs font-bold">
              <div className="p-3 bg-white rounded-xl border border-teal-100 text-teal-900">
                <span className="text-slate-400 block text-[10px]">Memory Domain</span>
                Easy Memory Match (4 min)
              </div>
              <div className="p-3 bg-white rounded-xl border border-teal-100 text-teal-900">
                <span className="text-slate-400 block text-[10px]">Attention Domain</span>
                Pattern Recall (Easy, 4 min)
              </div>
              <div className="p-3 bg-white rounded-xl border border-teal-100 text-teal-900">
                <span className="text-slate-400 block text-[10px]">Recall Domain</span>
                Story Recall (Light folklore, 4 min)
              </div>
            </div>
          </div>

          {
    /* Main Timeline Scheduler (Frame 14) */
  }
          <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-xs border border-[#0D7377]/15">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-2xl font-extrabold text-[#132A2F]">
                  Today's Daily Plan & Timeline
                </h3>
                <p className="text-xs sm:text-sm text-slate-500 font-medium">
                  Prescribe cognitive exercises for Tuesday, 25 August 2026
                </p>
              </div>
              <button
    onClick={() => setShowAddTaskModal(true)}
    className="px-4 py-2.5 bg-[#0D7377] hover:bg-[#0A5C5F] text-white font-extrabold text-xs sm:text-sm rounded-xl shadow-xs transition flex items-center gap-1.5"
  >
                <Plus className="w-4 h-4" />
                + Add Task
              </button>
            </div>

            {
    /* Timeline Cards */
  }
            <div className="space-y-4">
              {timelineTasks.map((task) => <div
    key={task.id}
    className="p-5 rounded-2xl border border-slate-200 bg-white hover:border-[#0D7377]/40 transition flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-2xs"
  >
                  <div className="flex items-center gap-4">
                    <div className="w-16 py-2 rounded-xl bg-[#F0F7F6] text-[#0D7377] font-black text-sm text-center border border-[#0D7377]/20 shrink-0">
                      {task.assignedTime || "09:00"}
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-1 flex-wrap">
                        <h4 className="text-lg font-black text-[#132A2F]">
                          {task.title}
                        </h4>
                        <span className="text-xs font-bold text-[#0D7377] bg-[#EAF6F4] px-2.5 py-0.5 rounded-full">
                          {task.domain}
                        </span>
                        <span className="text-xs font-bold text-amber-800 bg-amber-100 px-2 py-0.5 rounded-full">
                          Required
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 font-medium">
                        Duration: {task.durationMinutes} min · Status: {task.status}
                      </p>
                    </div>
                  </div>

                  {
    /* Doctor Actions */
  }
                  <div className="flex items-center gap-2 shrink-0">
                    <div className="flex items-center bg-slate-100 rounded-xl p-1 text-xs font-bold">
                      <button
    onClick={() => handleChangeDifficulty(task.id, "Easy")}
    className={`px-3 py-1 rounded-lg transition ${task.difficulty === "Easy" ? "bg-[#0D7377] text-white" : "text-slate-600"}`}
  >
                        Easy
                      </button>
                      <button
    onClick={() => handleChangeDifficulty(task.id, "Medium")}
    className={`px-3 py-1 rounded-lg transition ${task.difficulty === "Medium" ? "bg-[#0D7377] text-white" : "text-slate-600"}`}
  >
                        Medium
                      </button>
                    </div>

                    <button
    onClick={() => handleRemoveTask(task.id)}
    className="p-2 text-rose-600 hover:bg-rose-50 rounded-xl transition"
    title="Remove task"
  >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>)}
            </div>
          </div>

        </div>}

      {
    /* ========================================================= */
  }
      {
    /* TAB 3: AI ANALYTICS & LONGITUDINAL CHARTS (Frame 15, 16, 17) */
  }
      {
    /* ========================================================= */
  }
      {activeTab === "analytics" && <div className="space-y-6 animate-in fade-in duration-200">
          
          {
    /* Top 4 Cognitive Domain Scores (Frame 15) */
  }
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white rounded-3xl p-5 sm:p-6 shadow-xs border border-[#0D7377]/15 text-center">
              <span className="text-xs font-bold text-slate-500 uppercase block mb-1">Memory</span>
              <span className="text-3xl sm:text-4xl font-black text-amber-700">68%</span>
              <span className="text-xs font-bold text-amber-800 bg-amber-100 px-2 py-0.5 rounded-full mt-2 inline-block">
                Below Baseline
              </span>
            </div>

            <div className="bg-white rounded-3xl p-5 sm:p-6 shadow-xs border border-[#0D7377]/15 text-center">
              <span className="text-xs font-bold text-slate-500 uppercase block mb-1">Attention</span>
              <span className="text-3xl sm:text-4xl font-black text-emerald-700">86%</span>
              <span className="text-xs font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded-full mt-2 inline-block">
                Stable & Good
              </span>
            </div>

            <div className="bg-white rounded-3xl p-5 sm:p-6 shadow-xs border border-[#0D7377]/15 text-center">
              <span className="text-xs font-bold text-slate-500 uppercase block mb-1">Recall</span>
              <span className="text-3xl sm:text-4xl font-black text-amber-700">60%</span>
              <span className="text-xs font-bold text-amber-800 bg-amber-100 px-2 py-0.5 rounded-full mt-2 inline-block">
                Slight Slowing
              </span>
            </div>

            <div className="bg-white rounded-3xl p-5 sm:p-6 shadow-xs border border-[#0D7377]/15 text-center">
              <span className="text-xs font-bold text-slate-500 uppercase block mb-1">Pattern</span>
              <span className="text-3xl sm:text-4xl font-black text-[#0D7377]">91%</span>
              <span className="text-xs font-bold text-teal-800 bg-teal-100 px-2 py-0.5 rounded-full mt-2 inline-block">
                High Resilience
              </span>
            </div>
          </div>

          {
    /* Completion Time Graph (Frame 17: Easy vs Medium duration growth) */
  }
          <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-xs border border-[#0D7377]/15">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-6">
              <div>
                <h3 className="text-xl font-extrabold text-[#132A2F]">
                  Completion Time Graph (Frame 17)
                </h3>
                <p className="text-xs text-slate-500 font-medium">
                  Average session duration in minutes (Easy: 2 → 4 min, Medium: 7 → 10 min)
                </p>
              </div>
              <div className="flex items-center gap-3 text-xs font-bold">
                <span className="text-teal-700 flex items-center gap-1">
                  <span className="w-3 h-3 rounded-md bg-[#0D7377]" /> Easy Tasks
                </span>
                <span className="text-amber-700 flex items-center gap-1">
                  <span className="w-3 h-3 rounded-md bg-amber-500" /> Medium Tasks
                </span>
              </div>
            </div>

            {
    /* Bar Chart */
  }
            <div className="grid grid-cols-7 gap-2 sm:gap-4 items-end h-56 pt-6 px-2 border-b border-slate-200">
              {performance.map((day, idx) => <div key={idx} className="flex flex-col items-center gap-2 h-full justify-end">
                  <div className="w-full flex items-end justify-center gap-1 h-44">
                    {
    /* Easy bar */
  }
                    <div
    className="w-4 sm:w-6 bg-[#0D7377] rounded-t-lg transition-all"
    style={{ height: `${day.timeMinutesEasy / 12 * 100}%` }}
    title={`Easy: ${day.timeMinutesEasy} min`}
  />
                    {
    /* Med bar */
  }
                    <div
    className="w-4 sm:w-6 bg-amber-500 rounded-t-lg transition-all"
    style={{ height: `${day.timeMinutesMed / 12 * 100}%` }}
    title={`Med: ${day.timeMinutesMed} min`}
  />
                  </div>
                  <span className="text-[11px] font-bold text-slate-600 truncate w-full text-center">
                    {day.date}
                  </span>
                </div>)}
            </div>
            <p className="text-xs text-slate-500 font-medium mt-3">
              Baseline Target: Easy &lt; 3.5 min, Medium &lt; 7.0 min. Trend reflects mild psychomotor slowing without agitation.
            </p>
          </div>

        </div>}

      {
    /* ========================================================= */
  }
      {
    /* TAB 4: ALERT CENTER & EVIDENCE BREAKDOWN (Frame 18 & 19) */
  }
      {
    /* ========================================================= */
  }
      {activeTab === "alerts" && <div className="space-y-6 animate-in fade-in duration-200">
          
          <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-xs border-2 border-amber-300">
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 mb-6">
              <div className="flex items-start gap-4">
                <div className="w-14 h-14 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center shrink-0">
                  <AlertTriangle className="w-8 h-8" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-black text-amber-900 bg-amber-200 px-3 py-0.5 rounded-full uppercase">
                      [!] Alert Center
                    </span>
                    <span className="text-xs text-slate-500 font-semibold">{alert.timestamp}</span>
                  </div>
                  <h3 className="text-2xl font-black text-[#132A2F] mt-1">
                    {alert.title}
                  </h3>
                  <p className="text-sm text-slate-600 font-medium mt-0.5">
                    Patient: {profile.name} (Age {profile.age})
                  </p>
                </div>
              </div>

              <div className="flex gap-2">
                <button
    onClick={() => {
      setIsAlertAcknowledged(true);
      onAcknowledgeAlert(alert.id);
    }}
    className={`px-4 py-2.5 rounded-xl font-extrabold text-xs sm:text-sm transition flex items-center gap-1.5 ${isAlertAcknowledged ? "bg-emerald-100 text-emerald-800" : "bg-[#0D7377] hover:bg-[#0A5C5F] text-white shadow-xs"}`}
  >
                  <Check className="w-4 h-4" />
                  {isAlertAcknowledged ? "Acknowledged" : "[ACKNOWLEDGE]"}
                </button>
                <button
    onClick={() => alert(`Calling caregiver ${profile.caregiverName} at ${profile.caregiverPhone}`)}
    className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs sm:text-sm rounded-xl transition flex items-center gap-1.5"
  >
                  <Phone className="w-4 h-4 text-slate-600" />
                  [CONTACT FAMILY]
                </button>
              </div>
            </div>

            {
    /* Evidence Comparison Block (Frame 18) */
  }
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div className="bg-[#F8FAFA] p-4 rounded-2xl border border-slate-200">
                <span className="text-xs font-bold text-slate-500 uppercase block mb-1">Accuracy Trend</span>
                <span className="text-xl font-extrabold text-amber-700">88% → 68%</span>
                <span className="text-[11px] text-slate-500 block mt-1">Personal baseline drop</span>
              </div>

              <div className="bg-[#F8FAFA] p-4 rounded-2xl border border-slate-200">
                <span className="text-xs font-bold text-slate-500 uppercase block mb-1">Completion Time</span>
                <span className="text-xl font-extrabold text-amber-700">4.2 min → 7.8 min</span>
                <span className="text-[11px] text-slate-500 block mt-1">Observed elongation</span>
              </div>

              <div className="bg-[#F8FAFA] p-4 rounded-2xl border border-slate-200">
                <span className="text-xs font-bold text-slate-500 uppercase block mb-1">Observed Over</span>
                <span className="text-xl font-extrabold text-[#132A2F]">4 Sessions</span>
                <span className="text-[11px] text-slate-500 block mt-1">Comparable exercises</span>
              </div>
            </div>

            {
    /* Longitudinal Timeline Table (Frame 19: Alert Detail) */
  }
            <h4 className="text-sm font-extrabold text-[#132A2F] uppercase tracking-wider mb-3">
              7-Day Progression Timeline (Frame 19)
            </h4>
            <div className="grid grid-cols-7 gap-2 text-center text-xs mb-6">
              {alert.timelineData.map((d, i) => <div key={i} className="p-3 bg-[#F4F9F8] rounded-xl border border-slate-200">
                  <span className="text-slate-500 font-bold block">{d.day}</span>
                  <span className="text-sm sm:text-base font-black text-[#0D7377] block mt-1">{d.accuracy}%</span>
                  <span className="text-[10px] font-semibold text-slate-500">{d.time} min</span>
                </div>)}
            </div>

            {
    /* AI Explanation Without Jargon */
  }
            <div className="bg-emerald-50/70 p-4 rounded-2xl border border-emerald-200 text-xs sm:text-sm text-emerald-950 leading-relaxed font-medium">
              <strong>Clinical Rationale:</strong> "{alert.aiExplanation}"
            </div>
          </div>

        </div>}

      {
    /* ========================================================= */
  }
      {
    /* TAB 5: CLINICAL SESSION HISTORY TABLE (Frame 20) */
  }
      {
    /* ========================================================= */
  }
      {activeTab === "history" && <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-xs border border-[#0D7377]/15 space-y-6 animate-in fade-in duration-200">
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-2xl font-extrabold text-[#132A2F]">
                Clinical Session History (Frame 20)
              </h3>
              <p className="text-xs text-slate-500 font-medium">Filter by domain, date, or difficulty</p>
            </div>

            {
    /* Filter Buttons */
  }
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-500">Domain:</span>
              <select
    value={historyFilterDomain}
    onChange={(e) => setHistoryFilterDomain(e.target.value)}
    className="text-xs font-bold bg-[#F0F7F6] border border-[#0D7377]/20 rounded-xl px-3 py-1.5 text-slate-700"
  >
                <option value="all">All Domains</option>
                <option value="Memory">Memory</option>
                <option value="Attention">Attention</option>
                <option value="Recall">Recall</option>
              </select>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-bold uppercase text-[11px]">
                  <th className="pb-3">Date</th>
                  <th className="pb-3">Game</th>
                  <th className="pb-3">Difficulty</th>
                  <th className="pb-3">Score</th>
                  <th className="pb-3">Accuracy</th>
                  <th className="pb-3">Time</th>
                  <th className="pb-3">Errors</th>
                  <th className="pb-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                {filteredHistory.map((row) => <tr key={row.id} className="hover:bg-slate-50 transition">
                    <td className="py-3.5 font-bold text-[#132A2F]">{row.date}</td>
                    <td className="py-3.5 font-semibold">{row.game}</td>
                    <td className="py-3.5">
                      <span className="bg-slate-100 px-2 py-0.5 rounded-md text-xs font-bold">
                        {row.difficulty}
                      </span>
                    </td>
                    <td className="py-3.5 font-bold">{row.score}</td>
                    <td className="py-3.5 font-black text-[#0D7377]">{row.accuracy}</td>
                    <td className="py-3.5">{row.time}</td>
                    <td className="py-3.5 text-amber-700 font-bold">{row.errors}</td>
                    <td className="py-3.5">
                      <span className="text-emerald-700 font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" /> Completed
                      </span>
                    </td>
                  </tr>)}
              </tbody>
            </table>
          </div>

        </div>}

      {
    /* ========================================================= */
  }
      {
    /* TAB 6: CLINICAL / CARE NOTES (Frame 27) */
  }
      {
    /* ========================================================= */
  }
      {activeTab === "notes" && <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-xs border border-[#0D7377]/15 space-y-6 animate-in fade-in duration-200">
          
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-2xl font-extrabold text-[#132A2F]">
                Clinical & Care Notes (Frame 27)
              </h3>
              <p className="text-xs text-slate-500 font-medium">
                Distinguishes AI analysis, game metrics, caregiver logs, and physician orders
              </p>
            </div>
          </div>

          <form onSubmit={handleSaveDoctorNote} className="space-y-3">
            <textarea
    value={newClinicalNote}
    onChange={(e) => setNewClinicalNote(e.target.value)}
    placeholder="Enter physician follow-up instructions, prescription changes, or tele-consult findings..."
    rows={3}
    className="w-full text-sm p-4 rounded-2xl border border-slate-200 focus:ring-2 focus:ring-[#0D7377] focus:outline-none bg-[#FAFAFA]"
  />
            <button
    type="submit"
    className="px-6 py-3 bg-[#0D7377] hover:bg-[#0A5C5F] text-white font-extrabold text-sm rounded-xl transition shadow-xs"
  >
              Add Physician Note
            </button>
          </form>

          <div className="space-y-3 pt-4 border-t border-slate-100">
            {notes.map((note) => <div key={note.id} className="p-4 rounded-2xl bg-[#F8FAFA] border border-slate-200">
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="font-extrabold text-[#0D7377]">
                    {note.author} ({note.category})
                  </span>
                  <span className="text-slate-400 font-medium">{note.date}</span>
                </div>
                <p className="text-xs sm:text-sm text-slate-800 font-medium leading-relaxed">
                  {note.content}
                </p>
              </div>)}
          </div>

        </div>}

      {
    /* ========================================================= */
  }
      {
    /* TAB 7: WEEKLY COGNITIVE ACTIVITY REPORT (Frame 28) */
  }
      {
    /* ========================================================= */
  }
      {activeTab === "reports" && <div className="bg-white rounded-3xl p-6 sm:p-9 shadow-xs border border-[#0D7377]/15 space-y-6 animate-in fade-in duration-200">
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-slate-200 gap-4">
            <div>
              <span className="text-xs font-bold text-[#0D7377] uppercase tracking-wider">
                Comprehensive Summary · Frame 28
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-[#132A2F] font-display">
                Weekly Cognitive Activity Report
              </h2>
              <p className="text-xs text-slate-500 font-medium mt-1">
                Patient: {profile.name} (Age {profile.age}) · Period: 19 - 25 August 2026
              </p>
            </div>
            <button
    onClick={() => window.print()}
    className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-sm rounded-xl transition flex items-center gap-2 self-start"
  >
              <Printer className="w-4 h-4" />
              Print / Export Report
            </button>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-4 bg-[#F4F9F8] rounded-2xl border border-[#0D7377]/15">
              <span className="text-xs text-slate-500 font-bold block">Tasks Completed</span>
              <span className="text-2xl font-black text-[#0D7377]">18 / 21</span>
            </div>

            <div className="p-4 bg-[#F4F9F8] rounded-2xl border border-[#0D7377]/15">
              <span className="text-xs text-slate-500 font-bold block">Average Score</span>
              <span className="text-2xl font-black text-[#132A2F]">72%</span>
            </div>

            <div className="p-4 bg-amber-50 rounded-2xl border border-amber-200">
              <span className="text-xs text-amber-800 font-bold block">Memory Trend</span>
              <span className="text-2xl font-black text-amber-700">Declining</span>
            </div>

            <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-200">
              <span className="text-xs text-emerald-800 font-bold block">Attention</span>
              <span className="text-2xl font-black text-emerald-700">Stable</span>
            </div>
          </div>

          <div className="bg-[#EAF6F4] p-5 rounded-2xl border border-[#0D7377]/20">
            <h4 className="text-sm font-extrabold text-[#0D7377] mb-1">
              AI Longitudinal Summary
            </h4>
            <p className="text-xs sm:text-sm text-slate-800 font-medium leading-relaxed">
              "Memory-task performance has been below recent baseline across several comparable sessions (88% baseline to 68% recent). Reaction times lengthened to 7.8 min on average. Attention and Pattern domains demonstrate continued preservation. Daily plan adjusted to Easy cognitive load."
            </p>
          </div>

        </div>}

      {
    /* Add Task Modal */
  }
      {showAddTaskModal && <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-[#0D7377]/20 max-h-[90vh] overflow-y-auto">
            <h3 className="text-xl font-extrabold text-[#132A2F] mb-4">
              Schedule Cognitive Task
            </h3>
            
            {
    /* Quick Presets */
  }
            <div className="mb-4">
              <label className="text-xs font-bold text-slate-600 block mb-1.5">
                Standard Clinical Game Presets (1-10)
              </label>
              <div className="grid grid-cols-2 gap-1.5 text-[11px] font-bold">
                {[
    { name: "1. Memory Match", domain: "Memory" },
    { name: "2. Number Recall", domain: "Recall" },
    { name: "3. Picture Recall", domain: "Recall" },
    { name: "4. Pattern Recall", domain: "Attention" },
    { name: "5. Sound Match", domain: "Attention" },
    { name: "6. Simple Puzzle", domain: "Pattern" },
    { name: "7. Find the Object", domain: "Attention" },
    { name: "8. Color & Shape Match", domain: "Attention" },
    { name: "9. Daily Routine Recall", domain: "Recall" },
    { name: "10. Familiar Place Memory", domain: "Memory" }
  ].map((preset) => <button
    key={preset.name}
    type="button"
    onClick={() => {
      setNewTaskTitle(preset.name.toUpperCase());
      setNewTaskDomain(preset.domain);
    }}
    className="p-1.5 text-left bg-slate-50 hover:bg-teal-50 border border-slate-200 hover:border-teal-300 rounded-lg text-slate-700 truncate"
  >
                    {preset.name}
                  </button>)}
              </div>
            </div>

            <form onSubmit={handleAddNewTask} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-600 block mb-1">Activity Title</label>
                <input
    type="text"
    value={newTaskTitle}
    onChange={(e) => setNewTaskTitle(e.target.value)}
    className="w-full text-sm p-3 rounded-xl border border-slate-200 font-bold"
    required
  />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-600 block mb-1">Domain</label>
                  <select
    value={newTaskDomain}
    onChange={(e) => setNewTaskDomain(e.target.value)}
    className="w-full text-xs font-bold p-3 rounded-xl border border-slate-200"
  >
                    <option value="Memory">Memory</option>
                    <option value="Attention">Attention</option>
                    <option value="Recall">Recall</option>
                    <option value="Pattern">Pattern</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-600 block mb-1">Difficulty</label>
                  <select
    value={newTaskDifficulty}
    onChange={(e) => setNewTaskDifficulty(e.target.value)}
    className="w-full text-xs font-bold p-3 rounded-xl border border-slate-200"
  >
                    <option value="Easy">Easy</option>
                    <option value="Medium">Medium</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-600 block mb-1">Time (24h)</label>
                <input
    type="text"
    value={newTaskTime}
    onChange={(e) => setNewTaskTime(e.target.value)}
    className="w-full text-sm p-3 rounded-xl border border-slate-200 font-bold"
    placeholder="e.g. 14:00"
    required
  />
              </div>

              <div className="flex gap-3 pt-2">
                <button
    type="submit"
    className="flex-1 py-3 bg-[#0D7377] hover:bg-[#0A5C5F] text-white font-extrabold text-sm rounded-xl"
  >
                  Add to Schedule
                </button>
                <button
    type="button"
    onClick={() => setShowAddTaskModal(false)}
    className="py-3 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-sm rounded-xl"
  >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>}

    </div>;
};
